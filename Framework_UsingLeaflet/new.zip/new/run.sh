export FLASK_APP=test.py
export FLASK_ENV=development
flask run
